-- ============================================================
-- 【新プロジェクト側で実行】古いリアクションを書き出す
-- ============================================================
-- message_reactions は messages.id を参照せず、
-- チャンネル＋メッセージ時刻＋ユーザー名＋絵文字で持っている。
-- そのためメッセージ側の id が変わっても、チャンネルを名前で
-- 変換するだけで繋がる。

select
  c.name                   as channel_name,
  r.message_created_at,
  r.user_name,
  r.reaction,
  r.created_at
from public.message_reactions r
join public.channels c on c.id = r.channel_id
where r.message_created_at < '2026-06-11 00:00:00+00'
order by c.name, r.message_created_at;
