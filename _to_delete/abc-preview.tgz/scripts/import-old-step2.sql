-- ============================================================
-- 【本番側・CSV 取り込み後に実行】変換して本番へ流す
-- ============================================================

-- ① 取り込み前の確認：本番に対応するチャンネルがあるか
select
  t.channel_name                                as チャンネル名,
  count(*)                                      as CSVの件数,
  max(case when c.id is null then 0 else 1 end) as 本番に存在するか
from tmp_old_messages t
left join public.channels c on c.name = t.channel_name
group by t.channel_name
order by 3, 1;

-- ↑ 「本番に存在するか」が 0 の行があれば、そのチャンネルは取り込めない。
--   名前が変わっている可能性があるので、必要なら手当てする。
