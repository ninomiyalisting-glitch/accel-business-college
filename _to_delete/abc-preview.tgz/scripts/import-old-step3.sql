-- ============================================================
-- 【本番側・確認後に実行】実際に投入する
-- ============================================================

-- ② メッセージの投入。channel_id + created_at で重複を避ける
insert into public.messages
  (channel_id, user_name, slack_user_id, content, created_at, thread_ts, files_json, avatar_url)
select
  c.id, t.user_name, t.slack_user_id, t.content, t.created_at, t.thread_ts, t.files_json, t.avatar_url
from tmp_old_messages t
join public.channels c on c.name = t.channel_name
on conflict (channel_id, created_at) do nothing;

-- ③ リアクションの投入
insert into public.message_reactions
  (channel_id, message_created_at, user_name, reaction, created_at)
select
  c.id, t.message_created_at, t.user_name, t.reaction, coalesce(t.created_at, now())
from tmp_old_reactions t
join public.channels c on c.name = t.channel_name
on conflict (channel_id, message_created_at, user_name, reaction) do nothing;

-- ④ 検算
select
  (select count(*) from public.messages)                as メッセージ数,
  (select count(*) from public.message_reactions)       as リアクション数,
  (select min(created_at)::date from public.messages)   as 最古,
  (select count(*) from tmp_old_messages)               as CSVのメッセージ件数,
  (select count(*) from tmp_old_reactions)              as CSVのリアクション件数;

-- 問題なければ一時テーブルを片付ける
-- drop table tmp_old_messages;
-- drop table tmp_old_reactions;
