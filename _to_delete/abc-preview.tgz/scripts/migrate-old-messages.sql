-- ============================================================
-- 【新プロジェクト側で実行】古いメッセージとリアクションを書き出す
-- ============================================================
-- バックアップから復元した新プロジェクトの SQL Editor で実行する。
-- 結果を CSV でダウンロードし、本番へ取り込む。
--
-- チャンネルの uuid は本番で再作成されて変わっているため、
-- id ではなく「チャンネル名」を持ち出して、本番側で変換する。

-- ① 古いメッセージ（2026-06-11 より前）
select
  c.name                as channel_name,
  m.user_name,
  m.slack_user_id,
  m.content,
  m.created_at,
  m.thread_ts,
  m.files_json,
  m.avatar_url
from public.messages m
join public.channels c on c.id = m.channel_id
where m.created_at < '2026-06-11 00:00:00+00'
order by c.name, m.created_at;
