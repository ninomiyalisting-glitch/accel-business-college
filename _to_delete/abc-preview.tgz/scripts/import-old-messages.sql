-- ============================================================
-- 【本番側で実行】古いメッセージとリアクションを取り込む
-- ============================================================
-- 手順
--   1. 新プロジェクトから落とした CSV を、この下の一時テーブルに取り込む
--      （Supabase の Table Editor → Import data from CSV を使う）
--   2. その後、変換して本番テーブルへ流す部分を実行する
--
-- チャンネルは uuid が変わっているため、名前で本番の id に変換する。
-- 本番に無いチャンネル名は取り込まず、最後に一覧で報告する。

-- ── 一時テーブル（CSV の受け皿）────────────────────────────
drop table if exists tmp_old_messages;
create table tmp_old_messages (
  channel_name   text,
  user_name      text,
  slack_user_id  text,
  content        text,
  created_at     timestamptz,
  thread_ts      timestamptz,
  files_json     jsonb,
  avatar_url     text
);

drop table if exists tmp_old_reactions;
create table tmp_old_reactions (
  channel_name        text,
  message_created_at  timestamptz,
  user_name           text,
  reaction            text,
  created_at          timestamptz
);

-- ここで CSV を 2 つ取り込む（Table Editor から）。
-- 取り込めたら、以下を実行する。
