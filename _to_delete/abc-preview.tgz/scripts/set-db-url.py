#!/usr/bin/env python3
"""本番 DB への接続を確立して ~/.abc_dburl に保存する。

パスワードを URL に埋め込まない。@ : / などの記号が入っていても
URL が壊れないように、接続情報は別々に渡す。
"""
import os
import subprocess
import sys
import urllib.parse

REF = 'zcjgzviomuyirprfcrah'
HOST = 'aws-1-ap-south-1.pooler.supabase.com'
OUT = os.path.expanduser('~/.abc_dburl')

print('=' * 62)
print('Supabase でデータベースパスワードをコピーしてください。')
print(f'  https://supabase.com/dashboard/project/{REF}/settings/database')
print('  → Reset database password で再発行できます（サイトは止まりません）')
print()
print('コピーしたら、ここに戻って Enter だけ押してください。')
print('=' * 62)
input('準備できたら Enter: ')

pw = subprocess.run(['pbpaste'], capture_output=True, text=True).stdout.strip()
if not pw:
    sys.exit('クリップボードが空でした。')
if pw.startswith(('python3', 'postgresql://', 'export ', 'for ')):
    sys.exit('クリップボードにコマンド文が入っています。パスワードをコピーし直してください。')

specials = ''.join(sorted({c for c in pw if not c.isalnum()}))
print(f'\n読み取りました: {len(pw)} 文字' + (f' / 記号: {specials}' if specials else ' / 記号なし'))

# ユーザー名の 2 パターンを試す。pooler は user.ref 形式が正しいが、
# 設定によっては postgres のみのこともある。
users = [f'postgres.{REF}', 'postgres']

for user in users:
    print(f'\n  user = {user}')
    env = dict(os.environ, PGPASSWORD=pw)
    r = subprocess.run(
        ['psql', '-h', HOST, '-p', '5432', '-U', user, '-d', 'postgres',
         '-tAc', 'select count(*) from public.messages'],
        capture_output=True, text=True, env=env, timeout=40,
    )
    if r.returncode == 0:
        print(f'  成功（メッセージ {r.stdout.strip()} 件）')
        # 保存する URL は記号を安全に符号化する
        url = (f'postgresql://{urllib.parse.quote(user, safe="")}:'
               f'{urllib.parse.quote(pw, safe="")}@{HOST}:5432/postgres')
        with open(OUT, 'w') as fh:
            fh.write(url)
        os.chmod(OUT, 0o600)
        print(f'\n接続文字列を {OUT} に保存しました。次はこれを実行してください:')
        print('  export DATABASE_URL="$(cat ~/.abc_dburl)" && ~/Downloads/restore-sql/00-run.sh')
        sys.exit(0)
    for line in (r.stderr or '').strip().splitlines()[:2]:
        print(f'      {line}')

print('\n繋がりませんでした。パスワードが違う可能性が高いです。')
print('Reset database password で再発行し、表示された値をコピーして再実行してください。')
sys.exit(1)
