'use client'

import { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import {
  MessageSquare,
  Video,
  ArrowRight,
  Hash,
  CalendarDays,
  CheckCircle2,
  Clock,
  ChevronRight,
  Award,
  Users,
  Target,
  BookOpen,
  Heart,
  Compass,
  UserPlus,
} from 'lucide-react'
import { Message } from '@/types'
import { format } from 'date-fns'
import { ja } from 'date-fns/locale'
import Avatar from '@/components/Avatar'
import {
  EVENT_CATEGORY_STYLE as CATEGORY_STYLE,
  toCategory,
} from '@/lib/eventCategories'

const SLACK_USER_KEY = 'abc_slackUser'
const USER_NAME_KEY = 'abc_userName'

/** 実務従事更新ポイントの目標。期限までにこの点数を貯める */
const POINT_TARGET = 30

interface VimeoVideo {
  uri: string
  name: string
  duration: number
  created_time: string
  pictures: { sizes: { width: number; link: string }[] }
}

interface EventDate {
  id: string
  date: string
  end_time?: string | null
}

interface DashEvent {
  id: string
  title: string
  category: string | null
  cover_image_url: string | null
  created_by: string
  created_by_avatar: string | null
  deadline: string | null
  confirmed_date: string | null
  created_at: string
  dates: EventDate[]
  response_count: number
}

interface PointRow {
  id: string
  worked_on: string
  points: number
  activity: string
}

interface Article {
  id: string
  title: string
  cover_image_url: string | null
  author_name: string | null
  author_avatar: string | null
  created_at: string
  category_id: string | null
}

interface MemberRow {
  slack_user_id: string
  display_name: string
  avatar_url: string | null
  created_at: string
}

/** リアクション数つきの投稿 */
type HotMessage = Message & { reaction_count: number }

function getThumbnail(pictures: VimeoVideo['pictures']): string {
  const sizes = pictures?.sizes ?? []
  if (sizes.length === 0) return ''
  const suited = sizes.filter((s) => s.width <= 640)
  return (suited.length > 0 ? suited[suited.length - 1] : sizes[sizes.length - 1]).link
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  return `${m}:${String(s).padStart(2, '0')}`
}

/**
 * イベントの状態。一覧ページ（events/page.tsx）の phaseOf と同じ規則。
 * 片方だけ直すと同じイベントが 2 画面で違う扱いになるので、変えるときは両方直す。
 */
function phaseOf(ev: DashEvent): 'fixed' | 'adjusting' | 'ended' {
  const now = new Date()
  if (ev.confirmed_date) return new Date(ev.confirmed_date) < now ? 'ended' : 'fixed'
  if (ev.dates.length > 0 && ev.dates.every((d) => new Date(d.end_time ?? d.date) < now)) {
    return 'ended'
  }
  return 'adjusting'
}

function monthsUntil(deadline: string): number {
  const end = new Date(`${deadline}T23:59:59`)
  const now = new Date()
  if (end < now) return 0
  return Math.max(1, Math.ceil((end.getTime() - now.getTime()) / 86400000 / 30.4))
}

function greeting(): string {
  const h = new Date().getHours()
  if (h < 5) return 'こんばんは'
  if (h < 11) return 'おはようございます'
  if (h < 18) return 'こんにちは'
  return 'こんばんは'
}

/** 節の見出し。右端に一覧へのリンクを置く */
function SectionHead({
  icon,
  title,
  href,
  linkLabel,
}: {
  icon: React.ReactNode
  title: string
  href?: string
  linkLabel?: string
}) {
  return (
    <div className="mb-4 flex items-center gap-2.5">
      <span className="text-accel-text">{icon}</span>
      <h2 className="text-xl font-bold text-gray-900">{title}</h2>
      {href && (
        <Link
          href={href}
          className="ml-auto flex shrink-0 items-center gap-1 text-sm font-semibold text-accel-active hover:underline"
        >
          {linkLabel ?? 'すべて見る'} <ArrowRight size={14} />
        </Link>
      )}
    </div>
  )
}

/** 横スクロールの並び。スマホでも同じ形で見せる */
function Rail({ children }: { children: React.ReactNode }) {
  return (
    <div className="-mx-4 overflow-x-auto px-4 pb-2">
      <div className="flex gap-4">{children}</div>
    </div>
  )
}

function EmptyNote({ children }: { children: React.ReactNode }) {
  return (
    <p className="rounded-2xl border border-dashed border-gray-200 px-5 py-8 text-center text-gray-400">
      {children}
    </p>
  )
}

export default function DashboardPage() {
  const [userName, setUserName] = useState('')
  const [slackUserId, setSlackUserId] = useState<string | null>(null)
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null)

  const [events, setEvents] = useState<DashEvent[]>([])
  const [hotMessages, setHotMessages] = useState<HotMessage[]>([])
  const [channelMap, setChannelMap] = useState<Record<string, string>>({})
  const [videos, setVideos] = useState<VimeoVideo[]>([])
  const [articles, setArticles] = useState<Article[]>([])
  const [categories, setCategories] = useState<{ id: string; name: string; color: string }[]>([])
  const [newMembers, setNewMembers] = useState<MemberRow[]>([])
  const [loading, setLoading] = useState(true)

  const [points, setPoints] = useState<PointRow[]>([])
  const [renewalDeadline, setRenewalDeadline] = useState<string | null>(null)
  const [pointsLoading, setPointsLoading] = useState(true)

  useEffect(() => {
    try {
      const saved = localStorage.getItem(SLACK_USER_KEY)
      if (saved) {
        const u = JSON.parse(saved) as {
          display_name?: string
          slack_user_id?: string
          avatar_url?: string
        }
        setUserName(u.display_name ?? '')
        setSlackUserId(u.slack_user_id ?? null)
        setAvatarUrl(u.avatar_url ?? null)
      } else {
        setUserName(localStorage.getItem(USER_NAME_KEY) ?? '')
      }
    } catch {
      // 壊れた localStorage は無視してゲスト表示にする
    }
  }, [])

  useEffect(() => {
    const load = async () => {
      setLoading(true)

      const [channelsRes, eventsRes, articlesRes, catsRes, membersRes, vimeoResult] =
        await Promise.all([
          supabase.from('channels').select('id, name').eq('is_hidden', false),
          supabase
            .from('events')
            .select(
              'id, title, category, cover_image_url, created_by, created_by_avatar, deadline, confirmed_date, created_at'
            )
            .order('created_at', { ascending: false })
            .limit(40),
          supabase
            .from('articles')
            .select('id, title, cover_image_url, author_name, author_avatar, created_at, category_id')
            .eq('published', true)
            .order('created_at', { ascending: false })
            .limit(5),
          supabase.from('article_categories').select('id, name, color').order('name'),
          supabase
            .from('users')
            .select('slack_user_id, display_name, avatar_url, created_at')
            .order('created_at', { ascending: false })
            .limit(10),
          fetch('/api/vimeo/videos?project_id=25313251&recursive=1')
            .then((r) => r.json())
            .catch(() => null),
        ])

      const cmap: Record<string, string> = {}
      for (const c of channelsRes.data ?? []) cmap[c.id] = c.name
      setChannelMap(cmap)

      setArticles((articlesRes.data ?? []) as Article[])
      setCategories((catsRes.data ?? []) as { id: string; name: string; color: string }[])
      setNewMembers((membersRes.data ?? []) as MemberRow[])

      if (vimeoResult && Array.isArray(vimeoResult.data)) {
        setVideos((vimeoResult.data as VimeoVideo[]).slice(0, 4))
      }

      const eventsData = (eventsRes.data ?? []) as Omit<DashEvent, 'dates' | 'response_count'>[]
      const eventIds = eventsData.map((e) => e.id)
      const channelIds = Object.keys(cmap)

      const [msgsRes, datesRes, responsesRes] = await Promise.all([
        // 直近の投稿を多めに取り、この中からリアクションの多い順に 5 件選ぶ。
        // 「人気」を全期間で見ると古い投稿が居座るので、直近に限る。
        channelIds.length > 0
          ? supabase
              .from('messages')
              .select('*')
              .in('channel_id', channelIds)
              .order('created_at', { ascending: false })
              .limit(60)
          : Promise.resolve({ data: [] as Message[] }),
        eventIds.length > 0
          ? supabase
              .from('event_dates')
              .select('event_id, id, date, end_time')
              .in('event_id', eventIds)
              .order('date')
          : Promise.resolve({ data: [] as (EventDate & { event_id: string })[] }),
        eventIds.length > 0
          ? supabase.from('event_responses').select('event_id, responder_name').in('event_id', eventIds)
          : Promise.resolve({ data: [] as { event_id: string; responder_name: string }[] }),
      ])

      const datesByEvent: Record<string, EventDate[]> = {}
      for (const d of (datesRes.data ?? []) as (EventDate & { event_id: string })[]) {
        if (!datesByEvent[d.event_id]) datesByEvent[d.event_id] = []
        datesByEvent[d.event_id].push({ id: d.id, date: d.date, end_time: d.end_time })
      }
      const responderSets: Record<string, Set<string>> = {}
      for (const r of responsesRes.data ?? []) {
        if (!responderSets[r.event_id]) responderSets[r.event_id] = new Set()
        responderSets[r.event_id].add(r.responder_name)
      }
      setEvents(
        eventsData.map((e) => ({
          ...e,
          dates: datesByEvent[e.id] ?? [],
          response_count: responderSets[e.id]?.size ?? 0,
        }))
      )

      // リアクション数を数える。
      // message_reactions は messages の id ではなく
      // channel_id + メッセージ時刻で紐づくので、その組で数える。
      const recent = (msgsRes.data ?? []) as Message[]
      if (recent.length > 0) {
        const oldest = recent[recent.length - 1].created_at
        const { data: reactions } = await supabase
          .from('message_reactions')
          .select('channel_id, message_created_at')
          .in('channel_id', channelIds)
          .gte('message_created_at', oldest)

        const countBy = new Map<string, number>()
        for (const r of reactions ?? []) {
          const key = `${r.channel_id}__${r.message_created_at}`
          countBy.set(key, (countBy.get(key) ?? 0) + 1)
        }
        const withCount: HotMessage[] = recent.map((m) => ({
          ...m,
          reaction_count: countBy.get(`${m.channel_id}__${m.created_at}`) ?? 0,
        }))
        withCount.sort(
          (a, b) =>
            b.reaction_count - a.reaction_count ||
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        )
        setHotMessages(withCount.slice(0, 5))
      }

      setLoading(false)
    }
    load()
  }, [])

  useEffect(() => {
    if (!slackUserId) {
      setPointsLoading(false)
      return
    }
    const load = async () => {
      setPointsLoading(true)
      const [pointsRes, settingsRes] = await Promise.all([
        supabase
          .from('practice_points')
          .select('id, worked_on, points, activity')
          .eq('slack_user_id', slackUserId)
          .order('worked_on', { ascending: false }),
        supabase
          .from('user_settings')
          .select('renewal_deadline')
          .eq('slack_user_id', slackUserId)
          .maybeSingle(),
      ])
      setPoints((pointsRes.data ?? []) as PointRow[])
      setRenewalDeadline(settingsRes.data?.renewal_deadline ?? null)
      setPointsLoading(false)
    }
    load()
  }, [slackUserId])

  /** 開催決定を先に、その後ろに調整中。終了は出さない */
  const shownEvents = useMemo(() => {
    const fixed = events
      .filter((e) => phaseOf(e) === 'fixed')
      .sort((a, b) => (a.confirmed_date ?? '').localeCompare(b.confirmed_date ?? ''))
    const adjusting = events
      .filter((e) => phaseOf(e) === 'adjusting')
      .sort((a, b) => (b.deadline ?? b.created_at).localeCompare(a.deadline ?? a.created_at))
    return [...fixed, ...adjusting].slice(0, 8)
  }, [events])

  const pointSummary = useMemo(() => {
    const inRange = renewalDeadline
      ? points.filter((p) => p.worked_on <= renewalDeadline)
      : points
    const total = inRange.reduce((sum, p) => sum + p.points, 0)
    return {
      total,
      remaining: Math.max(0, POINT_TARGET - total),
      percent: Math.min(100, Math.round((total / POINT_TARGET) * 100)),
      months: renewalDeadline ? monthsUntil(renewalDeadline) : null,
    }
  }, [points, renewalDeadline])

  return (
    <div className="min-h-screen bg-surface-muted">
      <main className="max-w-content mx-auto px-4 py-8 pb-bottom-nav">
        {/* ── プロフィール ── */}
        <div className="mb-9 flex items-center gap-4 rounded-3xl border border-gray-100 bg-white px-5 py-5 shadow-sm">
          <Avatar src={avatarUrl} name={userName || 'ゲスト'} size={60} />
          <div className="min-w-0">
            <p className="text-sm text-gray-500">{greeting()}</p>
            <p className="truncate text-2xl font-bold text-gray-900">
              {userName || 'ゲスト'}
              <span className="ml-1 text-lg font-normal text-gray-500">さん</span>
            </p>
          </div>
          {slackUserId && (
            <Link
              href={`/members/${slackUserId}`}
              className="ml-auto flex shrink-0 items-center gap-1 text-sm font-semibold text-accel-active hover:underline"
            >
              プロフィール <ArrowRight size={14} />
            </Link>
          )}
        </div>

        {/* ── イベント・勉強会 ── */}
        <section className="mb-10">
          <SectionHead
            icon={<CalendarDays size={20} />}
            title="イベント・勉強会"
            href="/events"
          />
          {loading ? (
            <Rail>
              {[1, 2, 3].map((i) => (
                <div key={i} className="w-64 shrink-0 animate-pulse">
                  <div className="mb-2 h-36 rounded-2xl bg-gray-100" />
                  <div className="h-4 w-3/4 rounded bg-gray-100" />
                </div>
              ))}
            </Rail>
          ) : shownEvents.length === 0 ? (
            <EmptyNote>予定されているイベントはありません。</EmptyNote>
          ) : (
            <Rail>
              {shownEvents.map((ev) => {
                const fixed = phaseOf(ev) === 'fixed'
                const category = toCategory(ev.category)
                const upcoming = ev.dates.filter(
                  (d) => new Date(d.end_time ?? d.date) >= new Date()
                )
                return (
                  <Link
                    key={ev.id}
                    href={`/events/${ev.id}`}
                    className="group w-64 shrink-0 sm:w-72"
                  >
                    <div className="relative mb-3 aspect-[16/10] overflow-hidden rounded-2xl bg-accel-lightest">
                      {ev.cover_image_url ? (
                        // next/image は未登録ドメインで例外を投げページごと落とすので img を使う
                        <img
                          src={ev.cover_image_url}
                          alt=""
                          className="h-full w-full object-cover transition-transform group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-accel-secondary">
                          <CalendarDays size={32} />
                        </div>
                      )}
                      <span
                        className={`absolute left-2 top-2 rounded-full px-2.5 py-1 text-xs font-semibold ${
                          fixed
                            ? 'bg-accel-primary text-white'
                            : 'bg-white/95 text-amber-800'
                        }`}
                      >
                        {fixed ? '開催決定' : '日程調整中'}
                      </span>
                    </div>
                    <span
                      className={`mb-1.5 inline-block rounded-full px-2 py-0.5 text-xs font-semibold ${CATEGORY_STYLE[category]}`}
                    >
                      {category}
                    </span>
                    <p className="line-clamp-2 font-bold leading-snug text-gray-900">
                      {ev.title}
                    </p>
                    <p className="mt-1.5 flex items-center gap-1.5 text-sm text-gray-500">
                      {ev.confirmed_date ? (
                        <>
                          <CheckCircle2 size={14} className="text-accel-primary" />
                          {format(new Date(ev.confirmed_date), 'M月d日(E) HH:mm', { locale: ja })}
                        </>
                      ) : (
                        <>
                          <Clock size={14} />
                          候補 {upcoming.length}日 ・ {ev.response_count}人回答
                        </>
                      )}
                    </p>
                  </Link>
                )
              })}
            </Rail>
          )}
        </section>

        {/* ── 投稿 ── */}
        <section className="mb-10">
          <SectionHead
            icon={<MessageSquare size={20} />}
            title="投稿"
            href="/chat"
            linkLabel="チャットへ"
          />
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 animate-pulse rounded-2xl bg-white" />
              ))}
            </div>
          ) : hotMessages.length === 0 ? (
            <EmptyNote>投稿がありません。</EmptyNote>
          ) : (
            <ul className="overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm">
              {hotMessages.map((msg) => (
                <li key={msg.id} className="border-b border-gray-50 last:border-b-0">
                  <Link
                    href={`/chat?channel=${msg.channel_id}`}
                    className="flex items-start gap-3 px-5 py-4 transition-colors hover:bg-surface-muted"
                  >
                    <Avatar
                      src={msg.avatar_url ?? null}
                      name={msg.user_name}
                      size={40}
                      className="mt-0.5 flex-shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-2 leading-relaxed text-gray-800">
                        {msg.content || '(添付ファイル)'}
                      </p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-gray-400">
                        <span className="font-medium text-gray-500">{msg.user_name}</span>
                        {msg.reaction_count > 0 && (
                          <span className="inline-flex items-center gap-1 text-accel-active">
                            <Heart size={13} />
                            {msg.reaction_count}
                          </span>
                        )}
                        <span>{format(new Date(msg.created_at), 'M/d', { locale: ja })}</span>
                        <span className="ml-auto inline-flex items-center gap-0.5 rounded-full bg-surface-muted px-2 py-0.5 text-xs">
                          <Hash size={11} />
                          {channelMap[msg.channel_id] ?? ''}
                        </span>
                      </div>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* ── 動画 ── */}
        <section className="mb-10">
          <SectionHead
            icon={<Video size={20} />}
            title="動画"
            href="/videos"
            linkLabel="動画ライブラリ"
          />
          {loading ? (
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="mb-2 aspect-video rounded-2xl bg-gray-100" />
                  <div className="h-4 w-3/4 rounded bg-gray-100" />
                </div>
              ))}
            </div>
          ) : videos.length === 0 ? (
            <EmptyNote>動画がありません。</EmptyNote>
          ) : (
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              {videos.map((v) => {
                const thumb = getThumbnail(v.pictures)
                return (
                  <Link key={v.uri} href="/videos" className="group">
                    <div className="relative mb-2 aspect-video overflow-hidden rounded-2xl bg-gray-100">
                      {thumb && (
                        <img
                          src={thumb}
                          alt=""
                          className="h-full w-full object-cover transition-transform group-hover:scale-105"
                        />
                      )}
                      <span className="absolute bottom-1.5 right-1.5 rounded bg-black/70 px-1.5 font-mono text-xs text-white">
                        {formatDuration(v.duration)}
                      </span>
                    </div>
                    <p className="line-clamp-2 font-bold leading-snug text-gray-900">{v.name}</p>
                    <p className="mt-1 text-sm text-gray-400">
                      {format(new Date(v.created_time), 'yyyy/M/d', { locale: ja })}
                    </p>
                  </Link>
                )
              })}
            </div>
          )}
        </section>

        {/* ── メンバーコンテンツ ── */}
        <section className="mb-10">
          <SectionHead
            icon={<BookOpen size={20} />}
            title="メンバーコンテンツ"
            href="/articles"
            linkLabel="一覧へ"
          />
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 animate-pulse rounded-2xl bg-white" />
              ))}
            </div>
          ) : articles.length === 0 ? (
            <EmptyNote>記事がありません。</EmptyNote>
          ) : (
            <ul className="overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm">
              {articles.map((a) => (
                <li key={a.id} className="border-b border-gray-50 last:border-b-0">
                  <Link
                    href={`/articles/${a.id}`}
                    className="flex items-center gap-4 px-5 py-4 transition-colors hover:bg-surface-muted"
                  >
                    <div className="h-16 w-24 flex-shrink-0 overflow-hidden rounded-xl bg-accel-lightest">
                      {a.cover_image_url ? (
                        <img src={a.cover_image_url} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full items-center justify-center text-accel-secondary">
                          <BookOpen size={20} />
                        </div>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-2 font-bold leading-snug text-gray-900">{a.title}</p>
                      <div className="mt-1.5 flex items-center gap-2 text-sm text-gray-400">
                        {a.author_name && (
                          <>
                            <Avatar src={a.author_avatar} name={a.author_name} size={20} />
                            <span>{a.author_name}</span>
                          </>
                        )}
                        <span>{format(new Date(a.created_at), 'M/d', { locale: ja })}</span>
                      </div>
                    </div>
                    <ChevronRight size={18} className="flex-shrink-0 text-gray-300" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* ── 実務従事更新ポイント ── */}
        <section className="mb-10 overflow-hidden rounded-3xl bg-gradient-to-br from-accel-text to-accel-primary text-white shadow-sm">
          <div className="px-6 py-6 sm:px-8 sm:py-7">
            <div className="mb-6 flex items-center gap-3">
              <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl bg-white/15">
                <Award size={20} />
              </span>
              <h2 className="text-lg font-bold">実務従事更新ポイント</h2>
              <Link
                href={slackUserId ? `/members/${slackUserId}` : '/members'}
                className="ml-auto flex shrink-0 items-center gap-1 text-sm font-semibold text-white/90 hover:text-white hover:underline"
              >
                履歴を見る <ArrowRight size={14} />
              </Link>
            </div>

            {pointsLoading ? (
              <div className="animate-pulse space-y-4">
                <div className="h-10 w-40 rounded bg-white/15" />
                <div className="h-3 rounded-full bg-white/15" />
              </div>
            ) : !slackUserId ? (
              <p className="text-white/80">
                Slack アカウントでログインすると、あなたのポイント状況が表示されます。
              </p>
            ) : (
              <>
                <div className="flex flex-wrap items-end gap-2">
                  <span className="text-5xl font-bold leading-none tabular-nums">
                    {pointSummary.total}
                  </span>
                  <span className="text-xl font-semibold text-white/70">
                    / {POINT_TARGET} ポイント
                  </span>
                  {pointSummary.remaining === 0 && (
                    <span className="mb-1 ml-2 rounded-full bg-white px-3 py-1 text-sm font-bold text-accel-text">
                      目標達成
                    </span>
                  )}
                </div>

                <div className="mt-5 h-3 overflow-hidden rounded-full bg-white/20">
                  <div
                    className="h-full rounded-full bg-white transition-all duration-700"
                    style={{ width: `${pointSummary.percent}%` }}
                  />
                </div>

                <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
                  <div>
                    <div className="text-sm text-white/60">残りポイント</div>
                    <div className="text-2xl font-bold tabular-nums">{pointSummary.remaining}</div>
                  </div>
                  <div>
                    <div className="text-sm text-white/60">期限</div>
                    <div className="text-2xl font-bold">
                      {renewalDeadline
                        ? format(new Date(`${renewalDeadline}T00:00:00`), 'yyyy/M/d')
                        : '未設定'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-white/60">残り期間</div>
                    <div className="text-2xl font-bold">
                      {pointSummary.months === null
                        ? '—'
                        : pointSummary.months === 0
                          ? '期限切れ'
                          : `約${pointSummary.months}ヶ月`}
                    </div>
                  </div>
                </div>

                {!renewalDeadline && (
                  <p className="mt-6 text-sm text-white/80">
                    <Link href="/settings" className="font-semibold underline hover:text-white">
                      設定ページ
                    </Link>
                    で更新の期限日を登録すると、期限までの進捗が出ます。
                  </p>
                )}

                {renewalDeadline && pointSummary.remaining > 0 && (
                  <p className="mt-6 inline-flex items-center gap-2 text-sm text-white/80">
                    <Target size={16} className="flex-shrink-0" />
                    期限まであと {pointSummary.remaining} ポイント
                    {pointSummary.months !== null && pointSummary.months > 0 && (
                      <>（月あたり約 {Math.ceil(pointSummary.remaining / pointSummary.months)} ポイント）</>
                    )}
                  </p>
                )}
              </>
            )}
          </div>
        </section>

        {/* ── 新メンバー紹介 ── */}
        <section className="mb-10">
          <SectionHead
            icon={<UserPlus size={20} />}
            title="新しいメンバー"
            href="/members"
            linkLabel="メンバー一覧"
          />
          {loading ? (
            <Rail>
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="w-32 shrink-0 animate-pulse text-center">
                  <div className="mx-auto mb-2 h-20 w-20 rounded-full bg-gray-100" />
                  <div className="mx-auto h-4 w-16 rounded bg-gray-100" />
                </div>
              ))}
            </Rail>
          ) : newMembers.length === 0 ? (
            <EmptyNote>メンバーがいません。</EmptyNote>
          ) : (
            <Rail>
              {newMembers.slice(0, 8).map((m) => (
                <Link
                  key={m.slack_user_id}
                  href={`/members/${m.slack_user_id}`}
                  className="group w-32 shrink-0 text-center"
                >
                  <div className="mx-auto mb-2.5 transition-transform group-hover:scale-105">
                    <Avatar
                      src={m.avatar_url}
                      name={m.display_name}
                      size={80}
                      className="mx-auto ring-2 ring-white"
                    />
                  </div>
                  <p className="truncate font-bold text-gray-900">{m.display_name}</p>
                  <p className="mt-0.5 text-xs text-gray-400">
                    {format(new Date(m.created_at), 'yyyy/M月〜', { locale: ja })}
                  </p>
                </Link>
              ))}
            </Rail>
          )}
        </section>

        {/* ── 学びのコンテンツ ── */}
        {categories.length > 0 && (
          <section className="mb-10">
            <SectionHead
              icon={<Compass size={20} />}
              title="学びのコンテンツ"
              href="/articles"
              linkLabel="すべて見る"
            />
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {categories.map((c) => (
                <Link
                  key={c.id}
                  href={`/articles?category=${c.id}`}
                  className="flex items-center gap-2.5 rounded-2xl border border-gray-100 bg-white px-4 py-3.5 shadow-sm transition-colors hover:border-accel-secondary"
                >
                  <span
                    className="h-3 w-3 flex-shrink-0 rounded-full"
                    style={{ backgroundColor: c.color }}
                  />
                  <span className="truncate font-semibold text-gray-800">{c.name}</span>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* ── 使い方ガイド ── */}
        {/* ヘッダーの「ガイド」と同じ行き先にする。/guide は存在しない */}
        <Link
          href="/articles"
          className="flex items-center gap-4 rounded-3xl border border-gray-100 bg-white px-6 py-5 shadow-sm transition-colors hover:border-accel-secondary"
        >
          <span className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-accel-lightest text-accel-text">
            <Users size={22} />
          </span>
          <div className="min-w-0">
            <p className="font-bold text-gray-900">使い方ガイド</p>
            <p className="text-sm text-gray-500">このサイトでできることと、使い方をまとめています。</p>
          </div>
          <ChevronRight size={20} className="ml-auto flex-shrink-0 text-gray-300" />
        </Link>
      </main>
    </div>
  )
}
